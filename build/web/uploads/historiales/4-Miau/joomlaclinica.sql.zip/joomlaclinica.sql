-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 11-03-2013 a las 09:26:57
-- Versión del servidor: 5.1.53
-- Versión de PHP: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `joomlaclinica`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_cita`
--

CREATE TABLE IF NOT EXISTS `zk_cita` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `hora` time DEFAULT NULL,
  `informe` varchar(500) DEFAULT NULL,
  `tipo` int(1) DEFAULT NULL,
  `id_mascota` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `estado` tinyint(4) NOT NULL DEFAULT '2' COMMENT '0)Cancelado 1)Acudido 2)Pendiente',
  `id_empleado` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=59 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_cliente`
--

CREATE TABLE IF NOT EXISTS `zk_cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `apellidos` varchar(150) NOT NULL,
  `nif` varchar(10) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `ciudad` varchar(200) NOT NULL,
  `provincia` varchar(200) NOT NULL,
  `telefono` int(9) NOT NULL,
  `telefono2` int(9) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `codigopostal` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nif` (`nif`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_especie`
--

CREATE TABLE IF NOT EXISTS `zk_especie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `especie` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_factura`
--

CREATE TABLE IF NOT EXISTS `zk_factura` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero` int(11) NOT NULL,
  `cliente` int(11) NOT NULL,
  `empleado` int(11) NOT NULL,
  `factura` varchar(300) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_ficheros`
--

CREATE TABLE IF NOT EXISTS `zk_ficheros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_externo` int(11) NOT NULL,
  `tipo` smallint(2) NOT NULL COMMENT '1)Historial',
  `ruta` varchar(250) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_historial`
--

CREATE TABLE IF NOT EXISTS `zk_historial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mascota` int(11) NOT NULL,
  `id_veterinario` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tipo_visita` int(1) NOT NULL,
  `id_peso` int(11) NOT NULL,
  `anamnesis` varchar(500) DEFAULT NULL,
  `diagnostico` varchar(500) DEFAULT NULL,
  `tratamiento` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_iva`
--

CREATE TABLE IF NOT EXISTS `zk_iva` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valor` int(11) NOT NULL,
  `nombre` varchar(200) DEFAULT NULL,
  `descripcion` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_mascota`
--

CREATE TABLE IF NOT EXISTS `zk_mascota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chip` varchar(20) DEFAULT NULL,
  `nombre` varchar(50) NOT NULL,
  `sexo` varchar(6) DEFAULT NULL COMMENT '0)Macho 1)Hembra',
  `fecha_nac` date NOT NULL,
  `fecha_def` date DEFAULT NULL,
  `peso` float DEFAULT NULL,
  `altura` float DEFAULT NULL,
  `observaciones` varchar(250) DEFAULT NULL,
  `especie` varchar(100) DEFAULT NULL,
  `pelo` varchar(100) DEFAULT NULL COMMENT '1)Corto 2)Duro 3)Largo 4)Medio 5)Medio-Largo 6)Propio 7)Rizado',
  `raza` varchar(100) DEFAULT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_baja` datetime DEFAULT NULL,
  `id_cliente` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chip` (`chip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=48 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_mascota_vacuna`
--

CREATE TABLE IF NOT EXISTS `zk_mascota_vacuna` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mascota` int(11) NOT NULL,
  `vacuna` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `veterinario` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_pedido`
--

CREATE TABLE IF NOT EXISTS `zk_pedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_entrega` timestamp NULL DEFAULT NULL,
  `fecha_pago` timestamp NULL DEFAULT NULL,
  `pagado` tinyint(1) NOT NULL,
  `id_proveedor` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_pedido_linea`
--

CREATE TABLE IF NOT EXISTS `zk_pedido_linea` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad` int(11) NOT NULL,
  `coste` double NOT NULL,
  `id_pedido` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=54 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_peso`
--

CREATE TABLE IF NOT EXISTS `zk_peso` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mascota` int(11) NOT NULL,
  `valor` float NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_poblacion`
--

CREATE TABLE IF NOT EXISTS `zk_poblacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provincia` int(11) NOT NULL,
  `poblacion` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigopostal` (`poblacion`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8123 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_producto`
--

CREATE TABLE IF NOT EXISTS `zk_producto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_familia` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `codigo` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `pvp` float NOT NULL,
  `iva` int(2) NOT NULL,
  `precio` float DEFAULT NULL,
  `stock` int(11) NOT NULL,
  `descripcion` varchar(250) DEFAULT NULL,
  `fotografia` varchar(250) DEFAULT NULL,
  `observaciones` varchar(250) DEFAULT NULL,
  `unidad` varchar(10) DEFAULT NULL,
  `fecha_alta` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_producto_familia`
--

CREATE TABLE IF NOT EXISTS `zk_producto_familia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) NOT NULL,
  `descripcion` varchar(500) DEFAULT ' ',
  `tratamiento` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1)Tratamiento 0)Otro',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_proveedor`
--

CREATE TABLE IF NOT EXISTS `zk_proveedor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nif` varchar(20) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `poblacion` int(11) NOT NULL,
  `provincia` int(11) NOT NULL,
  `telefono` int(11) NOT NULL,
  `telefono2` int(11) DEFAULT NULL,
  `movil` int(11) DEFAULT NULL,
  `fax` int(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_baja` timestamp NULL DEFAULT NULL,
  `observaciones` varchar(400) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL COMMENT '0)Inactivo 1)Activo',
  `contacto` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_provincia`
--

CREATE TABLE IF NOT EXISTS `zk_provincia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provincia` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_raza`
--

CREATE TABLE IF NOT EXISTS `zk_raza` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `especie` int(11) NOT NULL,
  `raza` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_servicio`
--

CREATE TABLE IF NOT EXISTS `zk_servicio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(9) NOT NULL,
  `servicio` varchar(200) NOT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  `precio` float NOT NULL,
  `id_iva` int(11) NOT NULL,
  `id_familia` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_servicio_familia`
--

CREATE TABLE IF NOT EXISTS `zk_servicio_familia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) NOT NULL,
  `descripcion` varchar(500) DEFAULT ' ',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_usuario`
--

CREATE TABLE IF NOT EXISTS `zk_usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `tipo` int(2) NOT NULL DEFAULT '3' COMMENT '1)Admin 2)Veterinario 3)Empleado',
  `fecha_alta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nombre` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `nif` varchar(10) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `ciudad` int(9) NOT NULL,
  `provincia` int(9) NOT NULL,
  `telefono` int(9) DEFAULT NULL,
  `movil` int(9) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `nss` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user` (`user`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_vacuna`
--

CREATE TABLE IF NOT EXISTS `zk_vacuna` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `descripcion` varchar(1000) DEFAULT NULL,
  `especie` int(11) NOT NULL,
  `dias` int(4) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_venta`
--

CREATE TABLE IF NOT EXISTS `zk_venta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_cliente` int(11) NOT NULL,
  `id_vendedor` int(11) NOT NULL,
  `id_veterinario` int(11) DEFAULT NULL,
  `albaran` varchar(255) DEFAULT NULL COMMENT 'ruta del albaran',
  `factura` int(11) NOT NULL DEFAULT '0' COMMENT 'ruta de la factura',
  `facturado` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=62 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zk_venta_linea`
--

CREATE TABLE IF NOT EXISTS `zk_venta_linea` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_venta` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tipo` smallint(1) NOT NULL COMMENT '1)Producto 2)Servicio',
  `pvp` float DEFAULT NULL,
  `iva` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=238 ;
